package com.bebo.config;

public enum BrowserType {
    CHROME,
    IE,
    FIREFOX,
    SAFARI,
    EDGE,
    REMOTE
}
